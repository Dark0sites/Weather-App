/*
Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the “Software”), to 
deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, 
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

import React, { useEffect, useRef, useState } from "react";

function App() {
  const [backgroundImage, setBackgroundImage] = useState("")
  const [city, setCity] = useState('');
  const [temperature, setTemperature] = useState('');
  const [description, setDescription] = useState('');
  const [feelsLike, setFeelsLike] = useState('');
  const [humidity, setHumidity] = useState('');
  const [windSpeed, setWindSpeed] = useState('');

  function handleSearch(event) {
    event.preventDefault();
    const apiKey = 'YOUR_API_KEY';

    fetch(`https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`)
      .then(response => response.json())
      .then(data => {
        setTemperature(data.main.temp);
        setDescription(data.weather[0].description);
        setFeelsLike(data.main.feels_like);
        setHumidity(data.main.humidity);
        setWindSpeed(data.wind.speed);
      })
      .catch(error => console.log(error));
  }

  function handleCityChange(event) {
    setCity(event.target.value);
  }
  
  useEffect(() => {
    var hours = new Date().getHours();
    console.log(hours)
    if (hours >= 7 && hours < 12) {
      setBackgroundImage( "/morning.webp")
    }
    else if (hours >= 12 && hours < 18) {
      setBackgroundImage("/noon.webp")
    }
    else if (hours >= 18 && hours < 22) {
      setBackgroundImage("/afternoon.webp")
    }
    else if (hours >= 22 && hours < 7) {
      setBackgroundImage("/night.webp")
    }
  })

  return (
    <div className="app" style={{ "background": `url(${backgroundImage}) no-repeat center center/cover` }}>
      <form onSubmit={handleSearch} className="search-container">
        <input
          placeholder='Enter location'
          type="text"
          value={city}
          onChange={handleCityChange}/>
        <button type="submit" className="search_btn">Search</button>
      </form>
      <div className="container">
        <div className="top">
          <div className="location">
            <p>{city}</p>
          </div>
          <div className="temperature">
            <h1>{temperature}°C</h1>
          </div>
          <div className="description">
            <p>{description}</p>
          </div>
        </div>
        <div className="bottom">
          <div className="feels_like">
            <h2>{feelsLike}°C</h2>
            <p>Feels like</p>
          </div>
          <div className="humidity">
            <h2>{humidity}%</h2>
            <p>Humidity</p>
          </div>
          <div className="winds">
            <h2>{windSpeed} m/s</h2>
            <p>Wind speed</p>  
          </div>
        </div>
      </div>
    </div>
  )
}

export default App;
