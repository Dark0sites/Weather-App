import React, { useState } from "react";

function App() {
  const [city, setCity] = useState('');
  const [temperature, setTemperature] = useState('');
  const [description, setDescription] = useState('');
  const [feelsLike, setFeelsLike] = useState('');
  const [humidity, setHumidity] = useState('');
  const [windSpeed, setWindSpeed] = useState('');

  function handleSearch(event) {
    event.preventDefault();
    const apiKey = 'YOUR_API_KEY';

    fetch(`https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`)
      .then(response => response.json())
      .then(data => {
        setTemperature(data.main.temp);
        setDescription(data.weather[0].description);
        setFeelsLike(data.main.feels_like);
        setHumidity(data.main.humidity);
        setWindSpeed(data.wind.speed);
      })
      .catch(error => console.log(error));
  }

  function handleCityChange(event) {
    setCity(event.target.value);
  }
  
  return (
    <div className="app">
      {/* this website is public domain */}
      <form onSubmit={handleSearch} className="search-container">
        <input
          placeholder='Enter location'
          type="text"
          value={city}
          onChange={handleCityChange}/>
        <button type="submit" className="search_btn">Search</button>
      </form>
      <div className="container">
        <div className="top">
          <div className="location">
            <p>{city}</p>
          </div>
          <div className="temperature">
            <h1>{temperature}°C</h1>
          </div>
          <div className="description">
            <p>{description}</p>
          </div>
        </div>
        <div className="bottom">
          <div className="feels_like">
            <h2>{feelsLike}°C</h2>
            <p>Feels like</p>
          </div>
          <div className="humidity">
            <h2>{humidity}%</h2>
            <p>Humidity</p>
          </div>
          <div className="winds">
            <h2>{windSpeed} m/s</h2>
            <p>Wind speed</p>  
          </div>
        </div>
      </div>
      <p className="open">This website is public domain</p>
    </div>
  )
}

export default App;
